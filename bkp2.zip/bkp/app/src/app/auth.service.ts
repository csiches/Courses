import { Observable } from 'rxjs/Rx';
import { User } from './user';
import { Injectable, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import 'rxjs/add/operator/map';


@Injectable()
export class AuthService {

  private _isLogged = false;
  public _showNavBarEmitter: EventEmitter<boolean> = new EventEmitter<boolean>();

  public showNavBar(ifShow: boolean) {
    this._showNavBarEmitter.emit(ifShow);
 }


  IsLogged() {
    return this._isLogged;
  }

  constructor(private router: Router, private http: HttpClient) { }

  signIn(email, password) {

    this._isLogged = true;
    this.showNavBar(true);
    this.router.navigate(['/']);

      }


  signIn_with_service(email, password) {

    this.http.post('http://localhost:3001/api/signin', {email: email, password: password})
    .subscribe((res: User) => {
      console.log(res.token);

      this._isLogged = true;
      this.showNavBar(true);
      this.router.navigate(['/']);

    });
  }

  logout() {
    this._isLogged = false;
    this.showNavBar(false);
    this.router.navigate(['/login']);
  }


}
