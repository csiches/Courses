export interface User {
  email: string,
  password: string,
  displayName: string,
  token: string,
  signUpDate: Date
}



//displayName: "Carlos", token: "$2a$10$V6XK0eIe9HbCPtEmSPFoNu7YSTHVRCyl2cdRCUC6HcOQVF0ZRot3i", signUpDate: "2017-09-10T18:21:18.499Z", email: "csiches@mail.com"}
