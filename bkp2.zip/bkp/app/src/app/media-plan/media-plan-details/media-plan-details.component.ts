import { MediaPlanService } from './../media-plan.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { MediaPlan } from '../media-plan';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-plan-details',
  templateUrl: './media-plan-details.component.html',
  styleUrls: ['./media-plan-details.component.css']
})
export class MediaPlanDetailsComponent implements OnInit, OnDestroy {

  selectedMediaPlan: MediaPlan;
  private subscription: Subscription;
  private _idselected: any;

  constructor(
    private router: Router, private route: ActivatedRoute, private service: MediaPlanService
  ) {



  }

  ngOnInit() {

    this.subscription = this.route.params.subscribe(
      (params: any) => {
        this._idselected = params['id'];
        this.selectedMediaPlan = this.service.GetListPlans().find(obj => obj._id = this._idselected);
        //.subs(data => this.selectedMediaPlan = data);
      }
    );

    console.log(this.selectedMediaPlan);


    // this.route.params.subscribe((params: any) => {
    //   this._idselected = params['id'];
    //   //console.log(params['id']);
    // });

    // console.log(this._idselected);

    // console.log(this.service.GetListPlans().find(obj => obj._id = this._idselected));

  //   this.subscription = this.route.params.subscribe((params: any) => {
  //     this.selectedMediaPlan = this.service.data_plans.find(obj => obj._id = params['id']);
  //   }
  // );

  }


    public ngOnDestroy() {
      this.subscription.unsubscribe();
    }
}
