import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-plan',
  templateUrl: './media-plan.component.html'
})
export class MediaPlanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
