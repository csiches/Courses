import { MediaPlanService } from './../media-plan.service';
import { Component, OnInit } from '@angular/core';
import { MediaPlan } from '../media-plan';

@Component({
  selector: 'app-media-plan-list',
  templateUrl: './media-plan-list.component.html',
  styleUrls: ['./media-plan-list.component.css']
})
export class MediaPlanListComponent implements OnInit {

  plans: MediaPlan[] = [];

  constructor(private _servicePlan: MediaPlanService) {
     this.plans = this._servicePlan.GetListPlans();

  }

  ngOnInit() {
  }

}
