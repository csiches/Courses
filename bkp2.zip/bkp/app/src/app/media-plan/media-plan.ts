export interface MediaPlan {
    name: string,
    vertical?: string,
    categoria?: string,
    subcategoria?: string,
    producto?: string,
    _id: any,
    creation_date?: Date,
    last_modified_date?: Date

}

