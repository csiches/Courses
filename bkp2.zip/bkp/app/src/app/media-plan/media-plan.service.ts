import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


import { MediaPlan } from './media-plan';

@Injectable()
export class MediaPlanService {

  data_plans: MediaPlan[] =
  [
    {name: "Plan 1", _id: 1},
    {name: "Plan 2", _id: 2},
    {name: "Plan 3", _id: 3}
  ];

  constructor(private http: HttpClient) {

  }

  GetListPlans()  {
    return this.data_plans;
  }

  Save(name, vertical, categoria, subcategoria, producto ) {
    console.log('media-plan service');

    this.data_plans.push({name: name, _id: this.data_plans.length + 1});


    console.log(this.data_plans);


  }


  Save_bkp(name, vertical, categoria, subcategoria, producto ) {
    console.log('media-plan service');
    this.http.post('http://localhost:3001/api/mediaplan', {
      vertical: vertical,
      categoria: categoria,
      subcategoria: subcategoria,
      producto: producto,
      name: name
    })
    .subscribe((res: MediaPlan) => {
      console.log(res);

    });

  }

}
