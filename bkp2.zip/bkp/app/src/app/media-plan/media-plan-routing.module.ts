import { MediaPlanDetailsComponent } from './media-plan-details/media-plan-details.component';
import { MediaPlanFormComponent } from './media-plan-form/media-plan-form.component';
import { MediaPlanComponent } from './media-plan.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';





const routes: Routes = [
  // {path: '', component: MediaPlanComponent, children:
  // [
  //   {}

  // ]
  // }

  { path: '', component: MediaPlanComponent, children: [

    { path: 'new', component: MediaPlanFormComponent },
    { path: ':id', component: MediaPlanDetailsComponent }
    //,{ path: ':id/edit', component: MediaPlanDetailsComponent}

    //,
    //{ path: ':id', component: ContactDetailComponent },
    //{ path: ':id/edit', component: ContactFormComponent,
    //  canDeactivate: [ContactFormGuard]}
  ]}


];


// { path: '', component: ContactsComponent, children: [
//   { path: '', component: ContactStartComponent },
//   { path: 'new', component: ContactFormComponent ,
//     canDeactivate: [ContactFormGuard]},
//   { path: ':id', component: ContactDetailComponent },
//   { path: ':id/edit', component: ContactFormComponent,
//     canDeactivate: [ContactFormGuard]}
// ]}



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MediaPlanRoutingModule { }
