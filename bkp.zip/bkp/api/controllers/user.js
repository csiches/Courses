'use strict'

const mongoose = require('mongoose')
const User = require('../models/user')
const service = require('../services')

function singUp(req, res){
    console.log('test')
    // const user = new User({
    //     email: req.body.email,
    //     displayNama: req.body.displayName,
    //     password: req.body.password
    
    // })

    let user = new User()
    user.email = req.body.email
    user.displayName = req.body.displayName
    user.password = req.body.password
    
    console.log(user)

     user.save((err)=>{
         if (err) return res.status(500).send({message: `problemas al registrar al usuario ${err}`})
         return res.status(200).send({token: service.createToken(user)})
     })   

}

function singIn(req, res){
    
        //res.status(200).send({message: `usuario / password correctos`})

        //res.status(200).send(req.body)
    
        let puser = req.body.email
        let ppass = req.body.password
    
        // console.log(puser)
        //return res.status(200).send({message: `usuario / password correctos`})
    
    
          User.findOne({email: puser},"+password", function(err, user){
              if (err) {return res.status(500).send({message: `${err}`})}
              if (!user) {return res.status(401).send({message: `usuario / password incorrectos`})}
    
              //return res.status(200).send(user)
    
            //check this part  
             user.comparePassword(ppass, function(err, ismatch){
                 if (!ismatch) {return res.status(401).send({message: `usuario / password incorrectos`})}
                 if (ismatch) {return res.status(200).send(
                     {
                         message: `usuario / password correctos`,
                         displayName: user.displayName,
                         token: user.password,
                         signUpDate: user.signUpDate,
                         email: user.email 
                        })}
             })
          })
    
        }


function singInCheck(req, res){

    //res.status(200).send({message: `usuario / password correctos`})

    let puser = req.body.email
    let ppass = req.body.password

    // console.log(puser)
    //return res.status(200).send({message: `usuario / password correctos`})


      User.findOne({email: puser},"+password", function(err, user){
          if (err) {return res.status(500).send({message: `${err}`})}
          if (!user) {return res.status(401).send({message: `usuario / password incorrectos`})}

          //return res.status(200).send(user)

        //check this part  
         user.comparePassword(ppass, function(err, ismatch){
             if (!ismatch) {return res.status(401).send({message: `usuario / password incorrectos`})}
             if (ismatch) {return res.status(200).send(
                 {
                     message: `usuario / password correctos`,
                     displayName: user.displayName,
                     token: user.password,
                     signUpDate: user.signUpDate,
                     email: user.email 
                    })}
         })
      })

    }

function apitest(req, res){
    return res.status(200).send({message: `usuario logueado correctamente`})
}



function singIn2(req, res){
    console.log(req.body.email)
    //return res.status(200).send({message: 'PEru'})

    User.findOne({email: req.body.email}, "+password",function(err, user){
        console.log(user)

        if (user == null){
            return res.status(401).send({message: 'usuario/password incorrectos'})
        }

        // user.comparePassword(req.body.password, function(err, isMatch){
        //     if (err) return res.status(500).send({message: err}) 
        //     if (!isMatch) return res.status(401).send({message: 'usuario / password incorrectos'})

        // })

        return res.status(200).send(
            {
                message: 'usuario logueado correctamente', 
                displayName: user.displayName
            })
    })
    
    // User.findOne({email: req.body.email},"+password", function(err, user) {
    //     if (err) return res.status(500).send({message: err})
    //     console.log(user)
    //     if (!user) return res.status(401).send({message: 'usuario / password incorrectos'})

    //     user.comparePassword(req.body.password, function(err, isMatch){
    //         if (err) return res.status(500).send({message: err}) 
    //         if (!isMatch) return res.status(401).send({message: 'usuario / password incorrectos'})

    //       return res.status(200).send({
    //           message: `te has logueado correctamente`,
    //           token: service.createToken(user),
    //           displayName: user.displayName
    //       })
    //     } )
    // } )


 //          user[0].comparePassword(req.body.password, function(err, isMatch){

//             if (err) return res.status(500).send({message: err})
//             //console.log(`${isMatch}`)
//             if (!isMatch) return res.status(404).send({message: `usuario / password incorrectos`})
          
//          } )   
  
    //console.log('llego')
    //return res.status(200).send({message: 'llego'})

//      console.log(req.body.email)
// //    // User.find({email: req.body.email})


//      User.find({
//          email: req.body.email
//      },"+password", function(err, user)  {
//          if (err) return res.status(500).send({message: err})
//          if (user == undefined) return res.status(404).send({message: `no existe el usuario`})
//          if (!user[0]) return res.status(404).send({message: `no existe el usuario`})

  
//          user[0].comparePassword(req.body.password, function(err, isMatch){

//             if (err) return res.status(500).send({message: err})
//             //console.log(`${isMatch}`)
//             if (!isMatch) return res.status(404).send({message: `usuario / password incorrectos`})
          
//          } )

//          //console.log(user)

//          req.user = user[0]
//          //console.log(req.user)


//           res.status(200).send({
//               message: `te has logueado correctamente`,
//               token: service.createToken(user)
//           })
//       })
}



module.exports = {
    singIn,
    singUp,
    apitest
}