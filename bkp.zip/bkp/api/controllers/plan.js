
'use strict'

const MediaPlan = require('../models/plan')

function getMediaPlans(req, res){
    MediaPlan.find({}, (err, plans) => 
    {
        if (err) return res.status(500).send({message: `error al realizar la peticion ${err}`})
        if (!plans) return res.status(404).send({message: `no existen productos`})
        res.status(200).send({plans})    
    })
}

function saveMediaPlan(req, res){
    console.log('POST /api/plan')
    console.log(req.body)

    // producto: String,
    // categoria: String,
    // subcategoria: String,
    // rubro: String

    let obj = new MediaPlan()
    obj.producto = req.body.producto
    obj.categoria = req.body.categoria
    obj.subcategoria = req.body.subcategoria
    obj.vertical = req.body.vertical


    obj.save((err, objStored) => {
        if (err) res.status(500).send({message: 'error al guardar en BD'})
        res.status(200).send({product: objStored})

    })    

}


module.exports = {
    getMediaPlans,
    saveMediaPlan
}
