'use strict'

const express = require('express')

const productController = require('../controllers/product')
const mediaplanController = require('../controllers/plan')
const auth = require('../middlewares/auth')
const userController = require('../controllers/user')
const api = express.Router()

api.get('/mediaplan', mediaplanController.getMediaPlans)
api.post('/mediaplan', mediaplanController.saveMediaPlan)


api.post('/signup', userController.singUp)
api.post('/signin', userController.singIn)
api.post('/apitest', userController.apitest)




// api.get('/product', productController.getProducts )
// api.get('/product/:productId', productController.getProduct)
// api.post('/product', productController.saveProduct)
// api.put('/product/:productId', productController.updateProduct)
// api.delete('/product/:productId', productController.deleteProduct)

api.get('/private', auth.isAuth, (req, res) => {
    res.status(200).send({message: 'tienes acceso'})

})


module.exports = api