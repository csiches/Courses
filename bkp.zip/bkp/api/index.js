'use strict'

const mongoose = require('mongoose')
const app = require('./app')
const config = require('./config')

const port = process.env.PORT || 3001

mongoose.connect(config.db, { useMongoClient: true }, function (ignore, connection) {
    connection.onOpen()
  }).then(() => {
    console.log('connected')

    app.listen(config.port, () => {
        console.log(`Tesst running on ${config.port} `)

    })

    // app.listen(config.port, () => {
    //     console.log(`Tesst running on ${config.port} `)    

    
  })
  .catch(console.error)

// mongoose.connect(config.db, {useMongoClient: true},(ignore, connection) => {
//     if (err) {
//         console.log(`error al conectar a la base de datos: ${err}`)
//     }
//     console.log('conection a la base de datos establecida')
//     app.listen(config.port, () => {
//         console.log(`Tesst running on ${config.port} `)
//     })

// })    



