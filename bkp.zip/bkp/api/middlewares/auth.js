'use strict'


const services = require('../services')

function isAuth(req, res, next){
    console.log('llego')

    if (!req.headers.authorization){
        return res.status(403).send({message: `no tienes autorizacion`})

    }

    const token = req.headers.authorization.split(" ")[1]
    
    console.log(`este es el ${token}`)

    services.decodeToken(token)
        .then(response => {

            console.log(`este es el response ${response}`)

            req.user = response


            next()
        })
        .catch(response => {
            res.status(response.status)
        })

        // .then(response=>{
        //     req.user = response
        //     next()
        // })
        // .catch(response=>{
        //     res.status(response.status)
        // })

}

module.exports = {isAuth}

