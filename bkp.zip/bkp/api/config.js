module.exports = 
{
    port: process.env.PORT || 3001,
    db: process.env.MONGODB || 'mongodb://csiches:Saynomore1@ds127994.mlab.com:27994/dbcsichestest',
    SECRET_TOKEN: 'micodigosecreto'

}