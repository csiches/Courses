import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


import { MediaPlan } from './media-plan';

@Injectable()
export class MediaPlanService {

  constructor(private http: HttpClient) { 

  }


  Save(vertical, categoria, subcategoria, producto ){
    console.log('media-plan service');
    this.http.post('http://localhost:3001/api/mediaplan', {
      vertical: vertical,
      categoria: categoria,
      subcategoria: subcategoria,
      producto: producto 
    })
    .subscribe((res: MediaPlan) =>{
      console.log(res)

    })


  }

}
