import { MediaPlan } from './../media-plan';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-media-plan-list-item',
  templateUrl: './media-plan-list-item.component.html',
  styleUrls: ['./media-plan-list-item.component.css']
})
export class MediaPlanListItemComponent implements OnInit {

  @Input() plan: MediaPlan;

  constructor() {
    console.log(this.plan);
  }

  ngOnInit() {
  }

}
