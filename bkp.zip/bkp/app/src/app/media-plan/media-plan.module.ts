import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MediaPlanComponent } from './media-plan.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MediaPlanRoutingModule } from './media-plan-routing.module';


import { MediaPlanFormComponent } from './media-plan-form/media-plan-form.component';
import { MediaPlanService } from './media-plan.service';
import { MediaPlanListComponent } from './media-plan-list/media-plan-list.component';
import { MediaPlanListItemComponent } from './media-plan-list-item/media-plan-list-item.component';
import { MediaPlanDetailsComponent } from './media-plan-details/media-plan-details.component';




@NgModule({
  imports: [
    CommonModule,
    MediaPlanRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    MediaPlanListComponent, MediaPlanListItemComponent, MediaPlanComponent, MediaPlanFormComponent, MediaPlanDetailsComponent
  ],
  providers: [MediaPlanService]
})
export class MediaPlanModule { }
