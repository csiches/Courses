import { MediaPlan } from '../media-plan';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-plan-details',
  templateUrl: './media-plan-details.component.html',
  styleUrls: ['./media-plan-details.component.css']
})
export class MediaPlanDetailsComponent implements OnInit {

  selectedMediaPlan: MediaPlan;

  constructor() { }

  ngOnInit() {
  }

}
