import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MediaPlanService } from '../media-plan.service';



@Component({
  selector: 'app-media-plan-form',
  templateUrl: './media-plan-form.component.html',
  styleUrls: ['./media-plan-form.component.css']
})
export class MediaPlanFormComponent implements OnInit {

  fgPlan: FormGroup

  constructor(private fb: FormBuilder, private service: MediaPlanService) {
    this.fgPlan = fb.group({
      vertical: ['', Validators.required],
      categoria: ['', Validators.required],
      subcategoria: ['', Validators.required],
      producto: ['', Validators.required]
    })
  }

  onSave(){
    console.log(this.fgPlan.value.vertical)

    let vertical = this.fgPlan.value.vertical;
    let categoria = this.fgPlan.value.categoria;
    let subcategoria = this.fgPlan.value.subcategoria;
    let producto = this.fgPlan.value.producto;

    this.service.Save(vertical, categoria, subcategoria, producto);



  }



  ngOnInit() {
  }

}
