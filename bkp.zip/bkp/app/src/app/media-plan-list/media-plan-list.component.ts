import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-plan-list',
  templateUrl: './media-plan-list.component.html',
  styleUrls: ['./media-plan-list.component.css']
})
export class MediaPlanListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
