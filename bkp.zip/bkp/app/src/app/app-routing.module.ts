import { AuthGuardService } from './auth-guard.service';
import { HomeComponent } from './home/home.component';
import { CampaignComponent } from './campaign/campaign.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MediaPlanFormComponent } from './media-plan-form/media-plan-form.component';
import { MediaPlanListComponent } from './media-plan-list/media-plan-list.component';

const routes: Routes = [
  {
    path: '', pathMatch: 'full', component: HomeComponent, canActivate: [AuthGuardService]
  },
  {
    path: 'login', component: LoginComponent
  },
  // {
  //   path: 'media-plan', component: MediaPlanFormComponent
  // },

  {
    path: 'media-plan', component: MediaPlanListComponent
  },

  {
    path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuardService]
  },
  {
    path: 'campaign', component: CampaignComponent, canActivate: [AuthGuardService]
  }
  ,
  {
    path: 'home', component: HomeComponent, canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
