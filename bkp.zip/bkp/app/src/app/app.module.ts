import { HttpClientModule  } from '@angular/common/http';
import { AuthGuardService } from './auth-guard.service';
import { AuthService } from './auth.service';
import { CampaignComponent } from './campaign/campaign.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { MediaPlanFormComponent } from './media-plan-form/media-plan-form.component';
import { MediaPlanService } from './media-plan.service';
import { MediaPlanListComponent } from './media-plan-list/media-plan-list.component';


@NgModule({
  declarations: [
    AppComponent, MediaPlanFormComponent, LoginComponent, HeaderComponent, DashboardComponent, CampaignComponent, HomeComponent, MediaPlanListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [AuthService, AuthGuardService, MediaPlanService],
  bootstrap: [AppComponent]
})
export class AppModule { }
