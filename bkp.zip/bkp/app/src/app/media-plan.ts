export interface MediaPlan {
    vertical: string,
    categoria: string,
    subcategoria: string,
    producto: string,
    _id: any
    
}

