import { AuthService } from './../auth.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  private _showNavBar: boolean = false;

  constructor(private _auth: AuthService)
  {
    this._auth._showNavBarEmitter.subscribe(
      (mode: boolean) => {
        if (mode !== null) {
          this._showNavBar = mode;
        }
      }
    );

  }

  onLogout() {
    this._auth.logout();
  }

  ngOnInit() {
  }



}
